# Privacy Policy
Your data always belongs to you, and only you. SingleFile does not collect any data.

## How your data is protected and used
- By default, SingleFile does not send any data to our servers or any third parties. All your data is processed and stored locally on your device. 
- If you connect SingleFile to your Google Drive account, data is only transmitted from your browser to servers belonging to Google. 
- If you connect SingleFile to your Dropbox account, data is only transmitted from your browser to servers belonging to Dropbox. 
- If you save pages on GitHub, data is only transmitted from your browser to servers belonging to GitHub. 
- If you enable the "synchronize options" setting, your options will be sent to servers belonging to the vendor of the browser you are using. 
- If you enable the "add proof of existence" setting, a SHA256 hash of each saved page will be sent to servers belonging to Woleet. 
- When processing a page, SingleFile needs to inject temporary data into the page to save it accurately. SingleFile can download resources that are not displayed or not already cached but present in the page. When using SingleFile in Chromium-based browsers, websites can fetch resources declared in the "web_accessible_resources" section of the manifest.json file. Because of this, a website may be able to detect you are using SingleFile or have saved a page on the website with SingleFile.

## Customer support
When you request for customer support, we may ask for your email address to get back to you.

## Changes to our privacy policy
We keep our privacy notice under regular review and we will place any updates on this document. This privacy notice was last updated on December 2019.

## How to contact us
Please contact us if you have any questions about our privacy policy by email to gildas.lormeau &lt;at&gt; gmail.com.

## History
cf. https://github.com/gildas-lormeau/SingleFile/commits/master/privacy.md
